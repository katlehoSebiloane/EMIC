/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EMIC_SERVER;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;



/**
 *
 * @author Katleho Sebiloane
 */
public class Main extends Application {


    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
            Test_Client tst = new Test_Client();
            Scene s = new Scene(tst,900,600);
            primaryStage.setScene(s);
            primaryStage.setTitle("EMIC HL7 TEST SERVER");
            primaryStage.show();
    }
}
