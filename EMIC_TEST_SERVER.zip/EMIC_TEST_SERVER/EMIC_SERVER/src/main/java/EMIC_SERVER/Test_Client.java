package EMIC_SERVER;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;


public class Test_Client extends BorderPane {
        private Socket s = null;
        private InputStream in = null;
        private BufferedReader command = null;
        private TextArea Console= null;
        private Button Connect = null;
        private Button FakeData = null;
        private Label HL7_Test = new Label("Test Commands:");
        private VBox Button_Holder = new VBox();
        private ArrayList<String> Responses= new ArrayList<String>();

        Test_Client(){

            try{
                s = new Socket(InetAddress.getLocalHost(),15000);
                in = s.getInputStream();
                command = new BufferedReader(new InputStreamReader(in));
                Console = new TextArea("Server Response will show up here:\n");

                HL7_Test.setFont(Font.font("Segoe UI", FontWeight.EXTRA_LIGHT, FontPosture.REGULAR, 16));
                HL7_Test.setPadding(new Insets(15));
                HL7_Test.setTextFill(Color.WHITE);

                Connect = new Button("Connect");
                Connect.setStyle("-fx-background-color:#555555");
                Connect.setPadding(new Insets(15));
                Connect.setTextFill(Color.WHITE);
                Connect.setMinWidth(200);
                Connect.setMaxWidth(200);

                FakeData = new Button("Test Server");
                FakeData.setStyle("-fx-background-color:#555555");
                FakeData.setPadding(new Insets(15));
                FakeData.setTextFill(Color.WHITE);
                FakeData.setMinWidth(200);
                FakeData.setMaxWidth(200);



                Button_Holder.getChildren().addAll(HL7_Test,Connect,FakeData);
                Button_Holder.setStyle("-fx-background-color:#2d2d2d");
                Button_Holder.setSpacing(10);

                setLeft(Button_Holder);
                setCenter(Console);
                Connect.setOnAction(e->{
                    try {
                        PrintWriter pr = new PrintWriter(s.getOutputStream(),true);
                        pr.println("Connection Request!!");
                        String consolePopulation = command.readLine();
                        Console.appendText(consolePopulation);

                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                });

                FakeData.setOnAction(e->{
                    try {
                        PrintWriter pr = new PrintWriter(s.getOutputStream(),true);
                        pr.println("HL7");
                        String consolePopulation = command.readLine();
                        Console.appendText(consolePopulation+"\n");

                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                });



            } catch (UnknownHostException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }


        }

}
