package EMIC_SERVER;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import java.net.Socket;
import java.util.ArrayList;

public class Handler implements Runnable{
    private BufferedReader bufferedReader= null;
    private PrintWriter printWriter = null;

    public Handler(Socket socket) throws IOException {
        bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        printWriter = new PrintWriter(socket.getOutputStream(),true);

    }

    @Override
    public void run() {
        ArrayList<String> Messages = new ArrayList<>();

        while(true){
            try {
                String Command = bufferedReader.readLine();
                String Type = Command.split("[|]")[0];

                if(Command.equals("SHOW")){
                    System.out.println("Got the SHOW event");
                    printWriter.println(Messages.toString());
                }
                if(Command.equals("CONNECT")){
                    System.out.println("NEW CONNECTION DETECTED");
                    printWriter.println("Connected!\n");
                }
                if(Type.equals("MSH")){
                    System.out.println("EVENT DETECTED!");
                    Messages.add(bufferedReader.readLine());
                    printWriter.println("The Test Message Has Been Received");
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        }


    }
}
