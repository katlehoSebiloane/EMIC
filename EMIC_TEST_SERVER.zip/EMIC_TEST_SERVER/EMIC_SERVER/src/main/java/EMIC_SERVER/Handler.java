package EMIC_SERVER;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import java.net.Socket;
import java.util.ArrayList;

public class Handler implements Runnable{
    private BufferedReader bufferedReader= null;
    private PrintWriter printWriter = null;
    private ArrayList<String> Messages = null;

    public Handler(Socket socket) throws IOException {
        bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        printWriter = new PrintWriter(socket.getOutputStream(),true);
        Messages = new ArrayList<>();
        //printWriter.println("Connected");
    }

    @Override
    public void run() {
        while(true){
            try {
                String Command = bufferedReader.readLine();
                String Type = Command.split("[|]")[0];

                if(Command.equals("SHOW")){
                    System.out.println("Got the SHOW event");
                    printWriter.println("This worked like a dream!!!\n");

                }
                if(Type.equals("MSH")){
                    System.out.println("EVENT DETECTED!");
                    Messages.add(bufferedReader.readLine());
                    printWriter.println(Messages.toString());

                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        }


    }
}
