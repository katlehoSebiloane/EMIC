package com.company;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        BufferedReader PatientData= null;
        PrintWriter Test_Response = null;

        try{
            ServerSocket serverSocket = new ServerSocket(15000);
            System.out.println("The Server is Up And Running");
            while(true){
                Socket ClientConnection = serverSocket.accept();
                PatientData = new BufferedReader(new InputStreamReader(ClientConnection.getInputStream()));
                Test_Response = new PrintWriter(ClientConnection.getOutputStream(),true);
                String Tested = PatientData.readLine();
                if(Tested.equals("Connection Request!!")){
                    System.out.println("It Worked!");
                    Test_Response.println("Connected!!!");
                }
                if(Tested.equals("HL7")){
                    System.out.println("It Worked!");
                    Test_Response.println("MSH|^~\\&|EPIC|EPICADT|SMS|SMSADT|199912271408|CHARRIS|ADT^A04|1817457|D|2.5|\n" +
                            "PID||0493575^^^2^ID 1|454721||DOE^JOHN^^^^|DOE^JOHN^^^^|19480203|M||B|254 MYSTREET AVE^^MYTOWN^OH^44123^USA||(216)123-4567|||M|NON|400003403~1129086|\n" +
                            "NK1||ROE^MARIE^^^^|SPO||(216)123-4567||EC|||||||||||||||||||||||||||\n" +
                            "PV1||O|168 ~219~C~PMA^^^^^^^^^||||277^ALLEN MYLASTNAME^BONNIE^^^^|||||||||| ||2688684|||||||||||||||||||||||||199912271408||||||002376853\n" +
                            "\n");
                }

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
