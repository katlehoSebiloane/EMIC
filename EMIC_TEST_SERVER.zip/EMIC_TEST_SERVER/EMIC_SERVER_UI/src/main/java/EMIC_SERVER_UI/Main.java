/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EMIC_SERVER_UI;

import javafx.application.Application;
import javafx.concurrent.Task;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;


/**
 *
 * @author 27828
 */
public class Main extends Application {

    private  BufferedReader bufferedReader= null;
    private  PrintWriter printWriter = null;
    private  Socket socket = null;
    private  hl7_Interface hl7 = null;

    public static void main(String[] args) throws IOException {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {

        hl7 = new hl7_Interface();

        hl7.navigation.Connect.setOnAction(e->{
            try {
                socket = new Socket(InetAddress.getLocalHost(),15000);
                printWriter = new PrintWriter(socket.getOutputStream(),true);
                bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                Task<Integer> task = new Task<Integer>(){
                    @Override
                    protected Integer call() throws IOException {
                        System.out.println("Done Client Side Setup");
                        printWriter.println("CONNECT\n");
                        String line = bufferedReader.readLine();
                        hl7.console.appendText(line+"\n");
                        //hl7.console.appendText("Connected!\n");
                        return 0;
                    }
                };
                Thread t = new Thread(task);
                t.setDaemon(true);
                t.start();
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        });

        hl7.navigation.Read.setOnAction(e->{
            printWriter.println("SHOW");
            Task<Integer> task = new Task<Integer>(){
                @Override
                protected Integer call() throws IOException {
                    System.out.println("Getting ready to read");
                    String line = bufferedReader.readLine();
                    hl7.console.appendText(line+"\n");
                    return 0;
                }
            };
                Thread t = new Thread(task);
                t.setDaemon(true);
                t.start();
        });

        hl7.navigation.Test.setOnAction(e->{
            printWriter.println("MSH|^~`&|ECG REPORTING|ROCHESTER|ERIS|ROCHESTER|20110621050440||ORU^R01|20110621050440|P|2.1" +
                    "PID|||999999999||TEST^PATIENT||18450101|F" +
                    "OBR|||211088491|0^ADULT^ROCHECG|||20110620170631|||||||||M999999^^^^^^^RACFID||||||20110621060232||EC|F|||||||M999999^LASTNAME MD^FIRSTNAME^^^^^RACFID" +
                    "OBX||ST|93000.2^VENTRICULAR RATE EKG/MIN^CPT4|1|52|/SEC" +
                    "OBX||ST|93000.4^PR INTERVAL(MSEC)^CPT4|2|208|MSEC" +
                    "OBX||ST|93000.5^QRS - INTERVAL(MSEC)^CPT4|3|88|MSEC" +
                    "OBX||ST|93000.6^QT - INTERVAL(MSEC)^CPT4|4|466|MSEC" +
                    "OBX||ST|93000&PTL^PHYSICAL TEST LOCATION^CPT4|5|STMA" +
                    "OBX||ST|93000&PTR^PHYSICAL TEST ROOM^CPT4|6|04254" +
                    "OBX||CE|93000.17^^CPT4|7|21&101^Sinus bradycardia`T`with 1st degree A-V block^MEIECG" +
                    "OBX||CE|93000.17^^CPT4|8|1687^Otherwise normal ECG^MEIECG" +
                    "OBX||CE|93000&CMP^^CPT4|9|1301^When compared with ECG of^MEIECG" +
                    "OBX||TS|93000&CMD^EKG COMPARISON DATE^CPT4|10|201106171659" +
                    "OBX||CE|93000&CMP^^CPT4|11|1305^No significant change was found^MEIECG" +
                    "OBX||TX|93000.48^EKG COMMENT^CPT4|12|9917^LASTNAME MD^FIRSTNAME" +
                    "OBX||FT|93000^ECG 12-LEAD^CPT4|13|{\\rtf1\\ansi \\deff1\\deflang1033\\ {\\fonttbl{\\f1\\fmodern\\fcharset0 Courier;}{\\f2\\fmodern\\fcharset0 Courier;}} \\pard\\plain \\f1\\fs18\\par 20Jun2011 17:06\\par VENTRICULAR RATE 52\\par Sinus bradycardia with 1st degree A-V block\\par Otherwise normal ECG\\par When compared with ECG of 17-JUN-2011 16:59,\\par No significant change was found\\par 47507`S`'LASTNAME MD`S`'FIRSTNAME \\par }");

            Task<Integer> task = new Task<Integer>(){
                @Override
                protected Integer call() throws IOException {
                    hl7.console.appendText("Sending Test Message.........."+"\n");
                    String line = bufferedReader.readLine();
                    hl7.console.appendText(line+"\n");
                    return 0;
                }
            };
            Thread t = new Thread(task);
            t.setDaemon(true);
            t.start();


        });



        hl7.navigation.Close.setOnAction(e->{
            printWriter.close();
            try {
                socket.close();
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
            hl7.console.appendText("Closing socket safely........\n");

        });

        hl7.navigation.Restart.setOnAction(e->{
            try{
                hl7.console.setText("");
                hl7.console.appendText("Closing all sockets and streams.......\n");
                printWriter.close();
                bufferedReader.close();
                socket.close();
                hl7.console.appendText("Restarting Server.......\n");
                socket = new Socket(InetAddress.getLocalHost(),15000);
                printWriter = new PrintWriter(socket.getOutputStream(),true);
                bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                hl7.console.appendText("Client Side Setup Completed..........\n");
                printWriter.println("CONNECT\n");
                hl7.console.appendText(bufferedReader.readLine()+"\n");
                hl7.console.appendText("ALL DONE!!!!!\n");



            }catch (Exception e1){
                e1.printStackTrace();
            }


        });


        Scene s = new Scene( hl7,1000,800);
        primaryStage.setScene(s);
        primaryStage.setTitle("HL7 TEST SERVER");
        primaryStage.show();
    }


}
