package EMIC_SERVER_UI;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

public class hl7_Button extends Button {
    hl7_Button(String Name){
        setStyle("-fx-background-color:#444444;-fx-background-radius:0px");
        setPadding(new Insets(15));
        setTextFill(Color.WHITE);
        setFont(Font.font("Catamaran", FontWeight.EXTRA_LIGHT, FontPosture.REGULAR,20));
        setText(Name);
        setMinWidth(200);

        setOnMouseEntered(e->{
            setStyle("-fx-background-color:#666666;-fx-background-radius:0px");
        });
        setOnMouseExited(e->{
            setStyle("-fx-background-color:#444444;-fx-background-radius:0px");
        });

    }
}
