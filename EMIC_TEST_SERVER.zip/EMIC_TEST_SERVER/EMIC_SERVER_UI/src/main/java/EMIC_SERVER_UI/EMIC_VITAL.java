package EMIC_SERVER_UI;

import javafx.geometry.Insets;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class EMIC_VITAL extends VBox {
    private Text Title = new Text();
    private Text Reading = new Text();
    private Text Unit = new Text();
    private HBox ReadingUnit = new HBox();

    EMIC_VITAL(String t,String r, String u){
        Title.setText(t);
        Title.setFont(Font.font("Segoe UI", FontWeight.MEDIUM, FontPosture.ITALIC,18));
        Title.setFill(Color.WHITE);

        Reading.setText(r);
        Reading.setFont(Font.font("Segoe UI",FontWeight.BLACK,FontPosture.REGULAR,48));
        Reading.setFill(Color.WHITE);

        Unit.setText(u);
        Unit.setFont(Font.font("Segoe UI",FontWeight.LIGHT,FontPosture.REGULAR,16));
        Unit.setFill(Color.WHITE);

        ReadingUnit.getChildren().addAll(Reading,Unit);
        ReadingUnit.setSpacing(75);

        setPadding(new Insets(25));
        setPrefHeight(100);
        setPrefWidth(350);
        setStyle("-fx-background-color:#c4c4c4");
        getChildren().addAll(Title,ReadingUnit);

    }


}
