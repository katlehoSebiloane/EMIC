package EMIC_SERVER_UI;

import javafx.geometry.Insets;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.text.Text;

public class hl7_Interface extends BorderPane {
    public Navigation navigation= new Navigation();
    public Console console = new Console();
    private BorderPane ConsoleContainer = new BorderPane();
    public FlowPane fp = new FlowPane();
    private ScrollPane s = new ScrollPane();


    hl7_Interface(){
        fp.setHgap(10);
        fp.setVgap(10);
        fp.setPadding(new Insets(25));
        s.setContent(fp);
        fp.setMinWidth(1200);
        setLeft(navigation);
        ConsoleContainer.setBottom(console);
        ConsoleContainer.setCenter(s);
        setCenter(ConsoleContainer);
    }
}
