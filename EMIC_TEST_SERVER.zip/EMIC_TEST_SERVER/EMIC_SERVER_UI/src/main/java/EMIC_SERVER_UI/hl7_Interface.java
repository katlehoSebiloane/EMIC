package EMIC_SERVER_UI;

import javafx.scene.layout.BorderPane;

public class hl7_Interface extends BorderPane {
    public Navigation navigation= new Navigation();
    public Console console = new Console();
    private BorderPane ConsoleContainer = new BorderPane();

    hl7_Interface(){
        setLeft(navigation);
        ConsoleContainer.setBottom(console);
        setCenter(ConsoleContainer);
    }
}
