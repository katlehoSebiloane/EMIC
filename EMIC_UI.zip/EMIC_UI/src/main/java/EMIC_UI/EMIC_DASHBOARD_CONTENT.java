package EMIC_UI;

import javafx.geometry.Insets;
import javafx.scene.chart.Chart;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import javax.xml.validation.ValidatorHandler;
import java.lang.reflect.Array;
import java.util.ArrayList;

public class EMIC_DASHBOARD_CONTENT extends BorderPane {

    // Top Section Header with the emergency status and eta
    private final String Scenename = "Activity";
    // this is here to simply hold the chart and the grid making then one unit so that i can easily position them
    private VBox chart_grid = new VBox();
    // the gridpane is use the hold the vital sign cards
    private GridPane gp = new GridPane();
    // this arraylist holds the information that is displayed on the vital cards
    private ArrayList<String> Vital = new ArrayList<String>();
    // creating 6 vital cards
    private EMIC_VITALS EmV1 = null;
    private EMIC_VITALS EmV2 = null;
    private EMIC_VITALS EmV3 = null;
    private EMIC_VITALS EmV4 = null;
    private EMIC_VITALS EmV5 = null;
    private EMIC_VITALS EmV6 = null;

    // this just hold the chart because i wanted to add padding to it so the chart couldn't stretch from edge to edge
    private VBox Chart_Holder = new VBox();

    EMIC_DASHBOARD_CONTENT(Stage PrimaryStage){

         ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // I copied this code to be modified later !!!!!!!!!!!!!!!!
        final NumberAxis xAxis = new NumberAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Number of Month");
        //creating the chart
        final LineChart<Number,Number> lineChart =
                new LineChart<Number,Number>(xAxis,yAxis);

        lineChart.setTitle("Heart Rate");
        //defining a series
        XYChart.Series series = new XYChart.Series();
        series.setName("Heart Rate");
        //populating the series with data
        series.getData().add(new XYChart.Data(1, 23));
        series.getData().add(new XYChart.Data(2, 14));
        series.getData().add(new XYChart.Data(3, 15));
        series.getData().add(new XYChart.Data(4, 24));
        series.getData().add(new XYChart.Data(5, 34));
        series.getData().add(new XYChart.Data(6, 36));
        series.getData().add(new XYChart.Data(7, 22));
        series.getData().add(new XYChart.Data(8, 45));
        series.getData().add(new XYChart.Data(9, 43));
        series.getData().add(new XYChart.Data(10, 17));
        series.getData().add(new XYChart.Data(11, 29));
        series.getData().add(new XYChart.Data(12, 25));
        lineChart.getData().add(series);
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        Chart_Holder.getChildren().add(lineChart);
        Chart_Holder.setPadding(new Insets(31));
        Vital.add("Heart Rate");
        Vital.add("60");
        Vital.add("bpm");
        EmV1 = new EMIC_VITALS(Vital);
        EmV2 = new EMIC_VITALS(Vital);
        EmV3 = new EMIC_VITALS(Vital);
        EmV4 = new EMIC_VITALS(Vital);
        EmV5 = new EMIC_VITALS(Vital);
        EmV6 = new EMIC_VITALS(Vital);

        //  adding items to grid
        gp.add(EmV1,0,0);
        gp.add(EmV2,1,0);
        gp.add(EmV3,2,0);
        gp.add(EmV4,0,1);
        gp.add(EmV5,1,1);
        gp.add(EmV6,2,1);
        gp.setHgap(10);
        gp.setVgap(10);
        gp.setPadding(new Insets(30));

        chart_grid.setPadding(new Insets(50,25,0,25));


        //THIS IS WHERE WE ADD ALL OF THE ELEMENTS TO THE SCREEN
        Header HeaderTop = new Header(Scenename);
        BottomStats Bottom_Stats = new BottomStats(Scenename);
        chart_grid.getChildren().addAll(lineChart,gp);
        setBottom(Bottom_Stats);
        setTop(HeaderTop);
        setCenter(chart_grid);
        setMinWidth(1131);
        prefHeightProperty().bind(PrimaryStage.heightProperty());
        setStyle("-fx-background-color:#ffffff");

    }

}
