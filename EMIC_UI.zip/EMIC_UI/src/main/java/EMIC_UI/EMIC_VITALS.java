package EMIC_UI;

import javafx.geometry.Insets;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

import java.util.ArrayList;

public class EMIC_VITALS extends VBox {
        private Text Vital_Sign_Header = new Text();
        private Text Vital_Reading = new Text();
        private Text Vital_Unit_Measurement = new Text();
        private HBox ReadingUnit = new HBox();
    EMIC_VITALS(ArrayList<String> Vital_Sign){
        Vital_Sign_Header.setText(Vital_Sign.get(0));
        Vital_Reading.setText(Vital_Sign.get(1));
        Vital_Unit_Measurement.setText(Vital_Sign.get(2));
        ReadingUnit.getChildren().addAll(Vital_Reading,Vital_Unit_Measurement);
        ReadingUnit.setSpacing(75);
        getChildren().addAll(Vital_Sign_Header,ReadingUnit);
        setStyle("-fx-background-color:#c4c4c4");
        setPadding(new Insets(25));
        Vital_Sign_Header.setFill(Color.WHITE);
        Vital_Sign_Header.setFont(Font.font("Segoe UI", FontWeight.MEDIUM, FontPosture.ITALIC,18));
        Vital_Reading.setFill(Color.WHITE);
        Vital_Reading.setFont(Font.font("Segoe UI",FontWeight.BLACK,FontPosture.REGULAR,48));
        Vital_Unit_Measurement.setFill(Color.WHITE);
        Vital_Unit_Measurement.setFont(Font.font("Segoe UI",FontWeight.LIGHT,FontPosture.REGULAR,16));
        setPrefHeight(100);
        setPrefWidth(350);

    }

}
