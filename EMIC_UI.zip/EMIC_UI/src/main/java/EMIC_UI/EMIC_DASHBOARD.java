package EMIC_UI;

import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class EMIC_DASHBOARD extends GridPane {
        private String SceneName = "Activity";
        EMIC_DASHBOARD(Stage PrimaryStage){
                EMIC_NAVIGATION navigation = new EMIC_NAVIGATION(PrimaryStage,SceneName);
                EMIC_INFORMATION information = new EMIC_INFORMATION(PrimaryStage);
                EMIC_DASHBOARD_CONTENT content = new EMIC_DASHBOARD_CONTENT(PrimaryStage);
                add(navigation,0,0);
                add(content,1,0);
                add(information,2,0);
            }
}
